---
name: Button Collection System
colors:
  surface: '#f9faf2'
  surface-dim: '#d9dbd3'
  surface-bright: '#f9faf2'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4ed'
  surface-container: '#edefe7'
  surface-container-high: '#e7e9e1'
  surface-container-highest: '#e2e3dc'
  on-surface: '#191c18'
  on-surface-variant: '#42493e'
  inverse-surface: '#2e312c'
  inverse-on-surface: '#f0f1ea'
  outline: '#72796e'
  outline-variant: '#c2c9bb'
  surface-tint: '#3b6934'
  primary: '#154212'
  on-primary: '#ffffff'
  primary-container: '#2d5a27'
  on-primary-container: '#9dd090'
  inverse-primary: '#a1d494'
  secondary: '#615e56'
  on-secondary: '#ffffff'
  secondary-container: '#e8e2d7'
  on-secondary-container: '#67645b'
  tertiary: '#60233e'
  on-tertiary: '#ffffff'
  tertiary-container: '#7c3a55'
  on-tertiary-container: '#ffaac8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bcf0ae'
  primary-fixed-dim: '#a1d494'
  on-primary-fixed: '#002201'
  on-primary-fixed-variant: '#23501e'
  secondary-fixed: '#e8e2d7'
  secondary-fixed-dim: '#cbc6bb'
  on-secondary-fixed: '#1d1b15'
  on-secondary-fixed-variant: '#49473f'
  tertiary-fixed: '#ffd9e4'
  tertiary-fixed-dim: '#ffb0cc'
  on-tertiary-fixed: '#3b0520'
  on-tertiary-fixed-variant: '#71314c'
  background: '#f9faf2'
  on-background: '#191c18'
  surface-variant: '#e2e3dc'
  pitch-green: '#3D8B57'
  pitch-stripe: '#46A064'
  ink-text: '#0A2619'
  restrained-yellow: '#FFD700'
  plastic-highlight: rgba(255, 255, 255, 0.4)
  storage-shadow: rgba(0, 0, 0, 0.08)
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 72px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
  section-header:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
  button-number:
    fontFamily: Work Sans
    fontSize: 24px
    fontWeight: '800'
    lineHeight: '1'
  player-name:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: '1.4'
  stat-label:
    fontFamily: IBM Plex Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.05em
  stat-value:
    fontFamily: Work Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: '1'
  body-md:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  pitch-margin: 2rem
  button-gap: 1.5rem
  box-padding: 1rem
  grid-gutter: 16px
  mobile-side-margin: 1rem
---

## Brand & Style

The brand personality is that of a **curated historical archive**. It evokes the nostalgia of "futebol de botão" (button football), moving away from the high-octane energy of modern sports broadcasting toward a calm, tactile, and collectible experience. It treats each tournament and squad as a set of physical artifacts preserved in a digital album.

The design style is **Tactile / Skeuomorphic** with a heavy influence from **Minimalism**. It uses subtle depth, "plastic" highlights, and physical metaphors (like storage boxes and pitch layouts) to make digital elements feel like tangible hobbyist pieces. The aesthetic is grounded in high-quality typography and a restrained, "ink-on-paper" color palette.

**Target Audience:** Football enthusiasts, collectors, and those with a fondness for tabletop gaming and sports history.

## Colors

The palette is anchored by a **warm paper background** (`secondary_color_hex`), simulating an aged physical album. The **primary green** is a deep, scholarly ink color used for text and pitch boundaries. 

- **Primary:** Deep green ink for primary typography and structural icons.
- **Secondary:** Warm off-white/paper for the main page background.
- **Pitch Palette:** Two-tone alternating greens create the "half-field" texture.
- **Accents:** A muted yellow is used sparingly for highlights or badge accents to avoid a "neon" sports look.
- **Neutral:** Low-saturation tints of the paper color are used for compartments and storage box backgrounds.

## Typography

The system uses a hierarchy that blends modern clarity with a slightly historical, printed-matter feel. 

- **Headlines:** Uses `Manrope` for a bold, contemporary yet balanced look. Large display titles use tight letter spacing to mimic historical newspaper mastheads.
- **Body & Stats:** `Work Sans` provides a grounded, neutral, and highly readable foundation for player names and numerical data.
- **Labels:** `IBM Plex Sans` is utilized for technical labels (like "APPS", "GOALS") to provide a systematic, authoritative feel.

Typography scales aggressively; large titles reduce significantly on mobile, while player names and stats remain legible by prioritizing container width.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layers** and **Subtle Plastic Skeuomorphism**:

- **The Pitch:** Sits "inside" the page with a slight inset shadow, making it feel like a recessed tabletop.
- **The Buttons:** Use a distinct "top-down" highlight. A small, semi-transparent white "glint" on the top-left edge and a soft drop shadow below create the illusion of a convex plastic disc.
- **The Goalkeeper:** A rectangular block with similar plastic treatments but distinct geometry to signify its unique role.
- **The Storage Box:** Uses "ghost borders" and slight background shifts to create recessed compartments for substitute pieces.

## Shapes

The shape language is strictly dictated by the tabletop football metaphor:

- **Outfield Players:** Perfect circles (buttons).
- **Goalkeepers:** Rectangles with slightly rounded corners (0.5rem).
- **Storage Compartments:** Soft-edged rectangles to mimic molded plastic or cardboard trays.
- **Stat Chips:** Small rounded-sm containers to group labels and values together without cluttering the button surface.

## Components

### Player Button (Outfield)
- **Structure:** A circular container with a thick border (representing the rim of the button).
- **Badge Area:** Top center, reserved for a small circular or shield-shaped emblem.
- **Jersey Number:** Large, high-contrast text in the center.
- **Labeling:** Player name and position sit below the button piece, never overlapping the plastic disc.

### Goalkeeper Piece
- **Structure:** A landscape rectangle.
- **Layout:** Badge and number sit side-by-side or stacked on the left, with name and stats on the right, maintaining the unique "block" feel.

### Stat Card / Chip
- **Style:** Small, light-colored blocks with a vertical layout: Label (Top, small, uppercase) over Value (Bottom, bold). 
- **Grouping:** These are placed in a row below the player name for clarity.

### The "Storage Box" (Substitute Tray)
- **Style:** A large container with a slightly darker tint than the page background.
- **Compartments:** Individual cells for each substitute. Each cell contains a smaller version of the player button and its associated stats, laid out horizontally to save vertical space.

### Squad Summary Header
- **Style:** Large typography for the country name, accompanied by a horizontal row of "Data Cards" (Squad Size, Main 11 count, Team Code) styled as minimal, high-contrast boxes.